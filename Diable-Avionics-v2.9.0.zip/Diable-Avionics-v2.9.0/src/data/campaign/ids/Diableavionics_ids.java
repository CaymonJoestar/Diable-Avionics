package data.campaign.ids;

public class Diableavionics_ids {
    public static final String UNIQUE = "diableavionics_unique";
}