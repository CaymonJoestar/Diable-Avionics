# diable-avionics
